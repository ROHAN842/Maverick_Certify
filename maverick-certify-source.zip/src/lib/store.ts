// Simple localStorage-backed store for Maverick Certify (frontend mock).
import { useSyncExternalStore } from "react";

export type Candidate = {
  id: string;
  name: string;
  email: string;
  linkedinUrl?: string;
  certificateGenerated: boolean;
  emailSent: boolean;
  linkedinPostUrl?: string;
  linkedinPosted: boolean;
};

export type TemplateConfig = {
  imageDataUrl: string;
  // Name placement (0..1 relative coords)
  nameX: number;
  nameY: number;
  fontSize: number;
  fontColor: string;
  fontFamily: "serif" | "sans" | "script";
  // Optional date placement
  showDate: boolean;
  dateX: number;
  dateY: number;
  dateFontSize: number;
};

export type Batch = {
  id: string;
  name: string;
  date: string;
  createdAt: number;
  candidates: Candidate[];
  template?: TemplateConfig;
};

type State = { batches: Batch[] };

const KEY = "maverick-certify-v1";

const listeners = new Set<() => void>();
let state: State = load();

function load(): State {
  if (typeof window === "undefined") return { batches: [] };
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return { batches: [] };
}

function persist() {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch {}
}

function setState(next: State) {
  state = next;
  persist();
  listeners.forEach((l) => l());
}

export function useStore<T>(selector: (s: State) => T): T {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => selector(state),
    () => selector(state),
  );
}

export const actions = {
  createBatch(name: string, date: string): Batch {
    const batch: Batch = {
      id: crypto.randomUUID(),
      name,
      date,
      createdAt: Date.now(),
      candidates: [],
    };
    setState({ batches: [batch, ...state.batches] });
    return batch;
  },
  deleteBatch(id: string) {
    setState({ batches: state.batches.filter((b) => b.id !== id) });
  },
  getBatch(id: string): Batch | undefined {
    return state.batches.find((b) => b.id === id);
  },
  setCandidates(batchId: string, rows: Array<{ name: string; email: string; linkedinUrl?: string }>) {
    update(batchId, (b) => {
      b.candidates = rows.map((r) => ({
        id: crypto.randomUUID(),
        name: r.name,
        email: r.email,
        linkedinUrl: r.linkedinUrl,
        certificateGenerated: false,
        emailSent: false,
        linkedinPosted: false,
      }));
    });
  },
  setTemplate(batchId: string, template: TemplateConfig) {
    update(batchId, (b) => {
      b.template = template;
    });
  },
  markGenerated(batchId: string) {
    update(batchId, (b) => b.candidates.forEach((c) => (c.certificateGenerated = true)));
  },
  markEmailsSent(batchId: string) {
    update(batchId, (b) =>
      b.candidates.forEach((c) => {
        if (c.certificateGenerated) c.emailSent = true;
      }),
    );
  },
  setLinkedinPost(batchId: string, candidateId: string, url: string) {
    update(batchId, (b) => {
      const c = b.candidates.find((x) => x.id === candidateId);
      if (c) {
        c.linkedinPostUrl = url;
        c.linkedinPosted = !!url;
      }
    });
  },
};

function update(batchId: string, mut: (b: Batch) => void) {
  const batches = state.batches.map((b) => {
    if (b.id !== batchId) return b;
    const copy: Batch = JSON.parse(JSON.stringify(b));
    mut(copy);
    return copy;
  });
  setState({ batches });
}
