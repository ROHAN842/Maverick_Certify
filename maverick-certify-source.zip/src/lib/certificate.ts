import { jsPDF } from "jspdf";
import JSZip from "jszip";
import { saveAs } from "file-saver";
import type { Batch, Candidate, TemplateConfig } from "./store";

const FONT_MAP: Record<TemplateConfig["fontFamily"], string> = {
  serif: "'Times New Roman', Times, serif",
  sans: "'Helvetica', Arial, sans-serif",
  script: "'Great Vibes', cursive",
};

export async function renderCertificateToCanvas(
  template: TemplateConfig,
  candidateName: string,
  dateStr: string,
): Promise<HTMLCanvasElement> {
  const img = new Image();
  img.crossOrigin = "anonymous";
  img.src = template.imageDataUrl;
  await new Promise<void>((res, rej) => {
    img.onload = () => res();
    img.onerror = () => rej(new Error("Failed to load template image"));
  });

  const canvas = document.createElement("canvas");
  canvas.width = img.naturalWidth;
  canvas.height = img.naturalHeight;
  const ctx = canvas.getContext("2d")!;
  ctx.drawImage(img, 0, 0);

  ctx.fillStyle = template.fontColor;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  const px = (template.fontSize / 100) * canvas.width;
  ctx.font = `${px}px ${FONT_MAP[template.fontFamily]}`;
  ctx.fillText(candidateName, template.nameX * canvas.width, template.nameY * canvas.height);

  if (template.showDate) {
    const dpx = (template.dateFontSize / 100) * canvas.width;
    ctx.font = `${dpx}px ${FONT_MAP[template.fontFamily]}`;
    ctx.fillText(dateStr, template.dateX * canvas.width, template.dateY * canvas.height);
  }

  return canvas;
}

export async function generateCertificatePdf(
  template: TemplateConfig,
  candidateName: string,
  dateStr: string,
): Promise<Blob> {
  const canvas = await renderCertificateToCanvas(template, candidateName, dateStr);
  const orientation = canvas.width >= canvas.height ? "landscape" : "portrait";
  const pdf = new jsPDF({
    orientation,
    unit: "px",
    format: [canvas.width, canvas.height],
  });
  pdf.addImage(canvas.toDataURL("image/jpeg", 0.92), "JPEG", 0, 0, canvas.width, canvas.height);
  return pdf.output("blob");
}

export async function downloadCertificate(batch: Batch, candidate: Candidate) {
  if (!batch.template) throw new Error("No template configured");
  const blob = await generateCertificatePdf(batch.template, candidate.name, batch.date);
  saveAs(blob, `${slug(candidate.name)}-certificate.pdf`);
}

export async function downloadAllCertificates(batch: Batch) {
  if (!batch.template) throw new Error("No template configured");
  const zip = new JSZip();
  for (const c of batch.candidates) {
    const blob = await generateCertificatePdf(batch.template, c.name, batch.date);
    zip.file(`${slug(c.name)}-certificate.pdf`, blob);
  }
  const out = await zip.generateAsync({ type: "blob" });
  saveAs(out, `${slug(batch.name)}-certificates.zip`);
}

function slug(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}
