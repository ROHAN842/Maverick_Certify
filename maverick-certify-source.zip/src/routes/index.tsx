import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { actions, useStore } from "@/lib/store";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Award,
  Mail,
  Linkedin,
  Plus,
  Calendar,
  Users,
  ArrowRight,
  Trash2,
} from "lucide-react";

export const Route = createFileRoute("/")({
  component: Dashboard,
});

function Dashboard() {
  const batches = useStore((s) => s.batches);
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));

  const totals = batches.reduce(
    (acc, b) => {
      acc.candidates += b.candidates.length;
      acc.generated += b.candidates.filter((c) => c.certificateGenerated).length;
      acc.emailed += b.candidates.filter((c) => c.emailSent).length;
      acc.posted += b.candidates.filter((c) => c.linkedinPosted).length;
      return acc;
    },
    { candidates: 0, generated: 0, emailed: 0, posted: 0 },
  );

  function create() {
    if (!name.trim()) return;
    const b = actions.createBatch(name.trim(), date);
    setOpen(false);
    setName("");
    navigate({ to: "/batch/$batchId", params: { batchId: b.id } });
  }

  return (
    <div className="min-h-screen">
      <AppHeader />
      <main className="max-w-7xl mx-auto px-6 py-10">
        {/* Hero */}
        <section className="mb-10">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="max-w-2xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent text-accent-foreground text-xs font-semibold mb-4">
                <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
                Prototype · Frontend mock
              </div>
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
                Generate. Distribute. <span style={{ background: "var(--gradient-primary)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>Track.</span>
              </h1>
              <p className="mt-4 text-muted-foreground text-lg">
                Replace manual certificate work with one clean workflow — Excel in, branded PDFs out, every status visible.
              </p>
            </div>
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button size="lg" className="shadow-lg" style={{ background: "var(--gradient-primary)" }}>
                  <Plus className="mr-2 h-4 w-4" /> New batch
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create certification batch</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-2">
                  <div className="space-y-2">
                    <Label htmlFor="bname">Event / Batch name</Label>
                    <Input id="bname" placeholder="Python Training — April 2026" value={name} onChange={(e) => setName(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bdate">Event date</Label>
                    <Input id="bdate" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={create}>Create batch</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </section>

        {/* Stats */}
        <section className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          <Stat icon={<Users className="h-4 w-4" />} label="Candidates" value={totals.candidates} />
          <Stat icon={<Award className="h-4 w-4" />} label="Certificates" value={totals.generated} />
          <Stat icon={<Mail className="h-4 w-4" />} label="Emails sent" value={totals.emailed} />
          <Stat icon={<Linkedin className="h-4 w-4" />} label="LinkedIn posts" value={totals.posted} />
        </section>

        {/* Batches */}
        <section>
          <h2 className="text-xl font-semibold mb-4">Your batches</h2>
          {batches.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-border bg-card/40 py-16 px-6 text-center">
              <div
                className="mx-auto h-14 w-14 rounded-2xl flex items-center justify-center text-primary-foreground mb-4"
                style={{ background: "var(--gradient-primary)" }}
              >
                <Award className="h-6 w-6" />
              </div>
              <h3 className="font-semibold text-lg">No batches yet</h3>
              <p className="text-muted-foreground text-sm mt-1 max-w-sm mx-auto">
                Create your first certification batch to upload candidates, design the template, and generate certificates.
              </p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {batches.map((b) => {
                const gen = b.candidates.filter((c) => c.certificateGenerated).length;
                const sent = b.candidates.filter((c) => c.emailSent).length;
                const posted = b.candidates.filter((c) => c.linkedinPosted).length;
                return (
                  <div
                    key={b.id}
                    className="group rounded-2xl border border-border bg-card p-5 hover:shadow-lg hover:border-primary/30 transition-all"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <h3 className="font-semibold truncate">{b.name}</h3>
                        <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-1">
                          <Calendar className="h-3 w-3" /> {b.date}
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          if (confirm("Delete this batch?")) actions.deleteBatch(b.id);
                        }}
                        className="text-muted-foreground hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                        aria-label="Delete batch"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                    <div className="grid grid-cols-3 gap-2 mt-4 text-center">
                      <Mini label="Cands" value={b.candidates.length} />
                      <Mini label="Generated" value={gen} accent={gen > 0 ? "success" : undefined} />
                      <Mini label="Posted" value={posted} accent={posted > 0 ? "success" : undefined} />
                    </div>
                    <Link
                      to="/batch/$batchId"
                      params={{ batchId: b.id }}
                      className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:gap-2.5 transition-all"
                    >
                      Open batch <ArrowRight className="h-4 w-4" />
                    </Link>
                    <div className="text-[10px] text-muted-foreground mt-1">{sent} emails sent</div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: number }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <div className="flex items-center gap-2 text-muted-foreground text-xs font-medium uppercase tracking-wider">
        {icon} {label}
      </div>
      <div className="mt-2 text-3xl font-bold font-display tabular-nums">{value}</div>
    </div>
  );
}

function Mini({ label, value, accent }: { label: string; value: number; accent?: "success" }) {
  return (
    <div className="rounded-lg bg-muted/60 py-2">
      <div className={`text-lg font-semibold tabular-nums ${accent === "success" ? "text-success" : ""}`}>{value}</div>
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
    </div>
  );
}
