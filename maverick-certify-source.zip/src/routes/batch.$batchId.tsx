import { createFileRoute, Link, notFound, useParams } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import * as XLSX from "xlsx";
import { actions, useStore, type TemplateConfig } from "@/lib/store";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { downloadAllCertificates, downloadCertificate, renderCertificateToCanvas } from "@/lib/certificate";
import {
  ArrowLeft,
  Upload,
  FileSpreadsheet,
  Image as ImageIcon,
  Award,
  Mail,
  Linkedin,
  Download,
  CheckCircle2,
  Circle,
  Send,
  Loader2,
  Sparkles,
  AlertCircle,
} from "lucide-react";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/sonner";

export const Route = createFileRoute("/batch/$batchId")({
  component: BatchPage,
  notFoundComponent: () => (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-2xl font-semibold">Batch not found</h1>
        <Link to="/" className="text-primary mt-2 inline-block">Back to dashboard</Link>
      </div>
    </div>
  ),
});

const DEFAULT_TPL: Omit<TemplateConfig, "imageDataUrl"> = {
  nameX: 0.5,
  nameY: 0.5,
  fontSize: 6,
  fontColor: "#1a1a1a",
  fontFamily: "script",
  showDate: true,
  dateX: 0.5,
  dateY: 0.72,
  dateFontSize: 2.2,
};

function BatchPage() {
  const { batchId } = useParams({ from: "/batch/$batchId" });
  const batch = useStore((s) => s.batches.find((b) => b.id === batchId));
  if (!batch) throw notFound();

  const stats = {
    total: batch.candidates.length,
    generated: batch.candidates.filter((c) => c.certificateGenerated).length,
    emailed: batch.candidates.filter((c) => c.emailSent).length,
    posted: batch.candidates.filter((c) => c.linkedinPosted).length,
  };

  return (
    <div className="min-h-screen">
      <AppHeader />
      <Toaster richColors position="top-right" />
      <main className="max-w-7xl mx-auto px-6 py-8">
        <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-6">
          <ArrowLeft className="h-4 w-4" /> Dashboard
        </Link>

        <div className="flex items-end justify-between flex-wrap gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{batch.name}</h1>
            <p className="text-muted-foreground mt-1">Event date · {batch.date}</p>
          </div>
          <div className="flex gap-3">
            <Pill icon={<Award className="h-3.5 w-3.5" />} label={`${stats.generated}/${stats.total} generated`} />
            <Pill icon={<Mail className="h-3.5 w-3.5" />} label={`${stats.emailed} emailed`} />
            <Pill icon={<Linkedin className="h-3.5 w-3.5" />} label={`${stats.posted} posted`} />
          </div>
        </div>

        <Tabs defaultValue="candidates" className="space-y-6">
          <TabsList className="grid w-full max-w-2xl grid-cols-4">
            <TabsTrigger value="candidates"><Users />Candidates</TabsTrigger>
            <TabsTrigger value="template"><ImageIcon />Template</TabsTrigger>
            <TabsTrigger value="generate"><Sparkles />Generate</TabsTrigger>
            <TabsTrigger value="tracking"><Linkedin />Tracking</TabsTrigger>
          </TabsList>

          <TabsContent value="candidates"><CandidatesTab batchId={batchId} /></TabsContent>
          <TabsContent value="template"><TemplateTab batchId={batchId} /></TabsContent>
          <TabsContent value="generate"><GenerateTab batchId={batchId} /></TabsContent>
          <TabsContent value="tracking"><TrackingTab batchId={batchId} /></TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

function Users(props: React.SVGProps<SVGSVGElement>) {
  return <FileSpreadsheet className="h-4 w-4 mr-1.5" {...props} />;
}

function Pill({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-card border border-border text-xs font-medium">
      {icon} {label}
    </div>
  );
}

/* ---------- Candidates Tab ---------- */
function CandidatesTab({ batchId }: { batchId: string }) {
  const batch = useStore((s) => s.batches.find((b) => b.id === batchId))!;
  const fileRef = useRef<HTMLInputElement>(null);

  async function handleFile(f: File) {
    try {
      const buf = await f.arrayBuffer();
      const wb = XLSX.read(buf);
      const ws = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, { defval: "" });
      const parsed = rows
        .map((r) => {
          const name = String(r.Name ?? r.name ?? r["Candidate Name"] ?? "").trim();
          const email = String(r.Email ?? r.email ?? r["Email ID"] ?? "").trim();
          const linkedinUrl = String(r.LinkedIn ?? r.linkedin ?? r["LinkedIn URL"] ?? "").trim() || undefined;
          return { name, email, linkedinUrl };
        })
        .filter((r) => r.name && r.email);
      if (!parsed.length) {
        toast.error("No valid rows found. Need columns: Name, Email.");
        return;
      }
      actions.setCandidates(batchId, parsed);
      toast.success(`Loaded ${parsed.length} candidates`);
    } catch (e) {
      toast.error("Failed to parse file");
    }
  }

  function downloadSample() {
    const ws = XLSX.utils.json_to_sheet([
      { Name: "Aarav Sharma", Email: "aarav@example.com", LinkedIn: "https://linkedin.com/in/aarav" },
      { Name: "Priya Iyer", Email: "priya@example.com", LinkedIn: "" },
      { Name: "Rahul Mehta", Email: "rahul@example.com", LinkedIn: "" },
    ]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Candidates");
    XLSX.writeFile(wb, "candidates-sample.xlsx");
  }

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-border bg-card p-6">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h3 className="font-semibold flex items-center gap-2"><FileSpreadsheet className="h-4 w-4 text-primary" /> Upload candidate list</h3>
            <p className="text-sm text-muted-foreground mt-1">Excel or CSV with columns: <strong>Name</strong>, <strong>Email</strong>, optional <strong>LinkedIn</strong>.</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={downloadSample}><Download className="h-4 w-4 mr-2" />Sample</Button>
            <Button onClick={() => fileRef.current?.click()}><Upload className="h-4 w-4 mr-2" />Upload Excel</Button>
            <input
              ref={fileRef}
              type="file"
              accept=".xlsx,.xls,.csv"
              hidden
              onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
            />
          </div>
        </div>
      </div>

      {batch.candidates.length === 0 ? (
        <EmptyHint icon={<FileSpreadsheet />} title="No candidates yet" body="Upload an Excel file to get started." />
      ) : (
        <div className="rounded-2xl border border-border bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="text-left px-4 py-3">Name</th>
                <th className="text-left px-4 py-3">Email</th>
                <th className="text-left px-4 py-3">LinkedIn</th>
              </tr>
            </thead>
            <tbody>
              {batch.candidates.map((c) => (
                <tr key={c.id} className="border-t border-border">
                  <td className="px-4 py-3 font-medium">{c.name}</td>
                  <td className="px-4 py-3 text-muted-foreground">{c.email}</td>
                  <td className="px-4 py-3 text-muted-foreground truncate max-w-xs">{c.linkedinUrl || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/* ---------- Template Tab ---------- */
function TemplateTab({ batchId }: { batchId: string }) {
  const batch = useStore((s) => s.batches.find((b) => b.id === batchId))!;
  const [tpl, setTpl] = useState<TemplateConfig>(
    batch.template ?? { ...DEFAULT_TPL, imageDataUrl: "" },
  );
  const previewRef = useRef<HTMLDivElement>(null);
  const sampleName = batch.candidates[0]?.name || "Your Candidate Name";

  useEffect(() => {
    if (batch.template) setTpl(batch.template);
  }, [batch.template]);

  async function uploadImage(f: File) {
    const dataUrl = await new Promise<string>((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(r.result as string);
      r.onerror = rej;
      r.readAsDataURL(f);
    });
    setTpl((t) => ({ ...t, imageDataUrl: dataUrl }));
  }

  function save() {
    if (!tpl.imageDataUrl) {
      toast.error("Upload a template image first");
      return;
    }
    actions.setTemplate(batchId, tpl);
    toast.success("Template saved");
  }

  // Live preview canvas
  useEffect(() => {
    if (!tpl.imageDataUrl || !previewRef.current) return;
    let cancelled = false;
    renderCertificateToCanvas(tpl, sampleName, batch.date).then((c) => {
      if (cancelled || !previewRef.current) return;
      previewRef.current.innerHTML = "";
      c.style.maxWidth = "100%";
      c.style.height = "auto";
      c.style.display = "block";
      c.style.borderRadius = "8px";
      previewRef.current.appendChild(c);
    });
    return () => {
      cancelled = true;
    };
  }, [tpl, sampleName, batch.date]);

  return (
    <div className="grid lg:grid-cols-[380px_1fr] gap-6">
      <div className="rounded-2xl border border-border bg-card p-6 space-y-5">
        <div>
          <h3 className="font-semibold flex items-center gap-2"><ImageIcon className="h-4 w-4 text-primary" /> Template image</h3>
          <p className="text-xs text-muted-foreground mt-1">PNG/JPG. Landscape works best.</p>
          <label className="mt-3 block cursor-pointer">
            <div className="border-2 border-dashed border-border rounded-xl p-4 text-center hover:border-primary hover:bg-accent/30 transition-colors">
              <Upload className="h-5 w-5 mx-auto text-muted-foreground" />
              <div className="text-xs mt-1.5 text-muted-foreground">{tpl.imageDataUrl ? "Replace image" : "Choose template image"}</div>
            </div>
            <input
              type="file"
              accept="image/png,image/jpeg"
              hidden
              onChange={(e) => e.target.files?.[0] && uploadImage(e.target.files[0])}
            />
          </label>
        </div>

        <Field label="Font family">
          <Select value={tpl.fontFamily} onValueChange={(v) => setTpl({ ...tpl, fontFamily: v as TemplateConfig["fontFamily"] })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="script">Script (elegant)</SelectItem>
              <SelectItem value="serif">Serif (classic)</SelectItem>
              <SelectItem value="sans">Sans (modern)</SelectItem>
            </SelectContent>
          </Select>
        </Field>

        <Field label="Name color">
          <Input type="color" value={tpl.fontColor} onChange={(e) => setTpl({ ...tpl, fontColor: e.target.value })} className="h-10 w-full" />
        </Field>

        <SliderField label={`Name size (${tpl.fontSize.toFixed(1)})`} value={tpl.fontSize} min={2} max={12} step={0.1} onChange={(v) => setTpl({ ...tpl, fontSize: v })} />
        <SliderField label={`Name X (${(tpl.nameX * 100).toFixed(0)}%)`} value={tpl.nameX} min={0} max={1} step={0.01} onChange={(v) => setTpl({ ...tpl, nameX: v })} />
        <SliderField label={`Name Y (${(tpl.nameY * 100).toFixed(0)}%)`} value={tpl.nameY} min={0} max={1} step={0.01} onChange={(v) => setTpl({ ...tpl, nameY: v })} />

        <div className="flex items-center justify-between pt-2 border-t border-border">
          <Label htmlFor="showdate">Show date</Label>
          <Switch id="showdate" checked={tpl.showDate} onCheckedChange={(v) => setTpl({ ...tpl, showDate: v })} />
        </div>
        {tpl.showDate && (
          <>
            <SliderField label={`Date size (${tpl.dateFontSize.toFixed(1)})`} value={tpl.dateFontSize} min={1} max={6} step={0.1} onChange={(v) => setTpl({ ...tpl, dateFontSize: v })} />
            <SliderField label={`Date X (${(tpl.dateX * 100).toFixed(0)}%)`} value={tpl.dateX} min={0} max={1} step={0.01} onChange={(v) => setTpl({ ...tpl, dateX: v })} />
            <SliderField label={`Date Y (${(tpl.dateY * 100).toFixed(0)}%)`} value={tpl.dateY} min={0} max={1} step={0.01} onChange={(v) => setTpl({ ...tpl, dateY: v })} />
          </>
        )}

        <Button onClick={save} className="w-full" style={{ background: "var(--gradient-primary)" }}>
          Save template
        </Button>
      </div>

      <div className="rounded-2xl border border-border bg-card p-6">
        <h3 className="font-semibold mb-4">Live preview</h3>
        {tpl.imageDataUrl ? (
          <div ref={previewRef} className="bg-muted/30 rounded-lg p-2" />
        ) : (
          <EmptyHint icon={<ImageIcon />} title="Upload a template image" body="Drop a PNG or JPG to preview certificates with your candidate's name." />
        )}
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <Label className="text-xs uppercase tracking-wider text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}
function SliderField({ label, value, min, max, step, onChange }: { label: string; value: number; min: number; max: number; step: number; onChange: (v: number) => void }) {
  return (
    <div className="space-y-2">
      <Label className="text-xs uppercase tracking-wider text-muted-foreground">{label}</Label>
      <Slider value={[value]} min={min} max={max} step={step} onValueChange={(v) => onChange(v[0])} />
    </div>
  );
}

/* ---------- Generate Tab ---------- */
function GenerateTab({ batchId }: { batchId: string }) {
  const batch = useStore((s) => s.batches.find((b) => b.id === batchId))!;
  const [busy, setBusy] = useState<"none" | "all" | "email">("none");
  const ready = batch.template?.imageDataUrl && batch.candidates.length > 0;

  async function generateAll() {
    if (!ready) return;
    setBusy("all");
    try {
      await downloadAllCertificates(batch);
      actions.markGenerated(batchId);
      toast.success("Certificates generated and downloaded as ZIP");
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy("none");
    }
  }

  async function sendEmails() {
    setBusy("email");
    // Simulated email sending
    await new Promise((r) => setTimeout(r, 1200));
    actions.markEmailsSent(batchId);
    toast.success(`Emails sent to ${batch.candidates.filter((c) => c.certificateGenerated).length} recipients (simulated)`);
    setBusy("none");
  }

  return (
    <div className="space-y-6">
      {!ready && (
        <div className="rounded-xl border border-warning/30 bg-warning/10 p-4 flex gap-3 text-sm">
          <AlertCircle className="h-5 w-5 text-warning shrink-0" />
          <div>
            <strong>Setup required.</strong> {!batch.candidates.length ? "Upload candidates" : ""}{!batch.candidates.length && !batch.template?.imageDataUrl ? " and " : ""}{!batch.template?.imageDataUrl ? "configure a template" : ""} first.
          </div>
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-4">
        <ActionCard
          icon={<Sparkles className="h-5 w-5" />}
          title="Generate certificates"
          desc="Render one PDF per candidate using your template, then download as a ZIP."
          actionLabel={busy === "all" ? "Generating..." : "Generate & download"}
          disabled={!ready || busy !== "none"}
          loading={busy === "all"}
          onClick={generateAll}
        />
        <ActionCard
          icon={<Send className="h-5 w-5" />}
          title="Send emails"
          desc="Simulated dispatch — marks each generated candidate as emailed."
          actionLabel={busy === "email" ? "Sending..." : "Send emails"}
          disabled={!batch.candidates.some((c) => c.certificateGenerated) || busy !== "none"}
          loading={busy === "email"}
          onClick={sendEmails}
        />
      </div>

      {batch.candidates.length > 0 && (
        <div className="rounded-2xl border border-border bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="text-left px-4 py-3">Candidate</th>
                <th className="text-left px-4 py-3">Email</th>
                <th className="px-4 py-3">Cert</th>
                <th className="px-4 py-3">Email</th>
                <th className="text-right px-4 py-3">Action</th>
              </tr>
            </thead>
            <tbody>
              {batch.candidates.map((c) => (
                <tr key={c.id} className="border-t border-border">
                  <td className="px-4 py-3 font-medium">{c.name}</td>
                  <td className="px-4 py-3 text-muted-foreground">{c.email}</td>
                  <td className="px-4 py-3 text-center"><StatusDot ok={c.certificateGenerated} /></td>
                  <td className="px-4 py-3 text-center"><StatusDot ok={c.emailSent} /></td>
                  <td className="px-4 py-3 text-right">
                    <Button
                      size="sm"
                      variant="ghost"
                      disabled={!batch.template?.imageDataUrl}
                      onClick={async () => {
                        try {
                          await downloadCertificate(batch, c);
                          if (!c.certificateGenerated) actions.markGenerated(batchId);
                        } catch (e) {
                          toast.error((e as Error).message);
                        }
                      }}
                    >
                      <Download className="h-3.5 w-3.5 mr-1" /> PDF
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function ActionCard({ icon, title, desc, actionLabel, disabled, loading, onClick }: { icon: React.ReactNode; title: string; desc: string; actionLabel: string; disabled?: boolean; loading?: boolean; onClick: () => void }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <div
        className="h-11 w-11 rounded-xl flex items-center justify-center text-primary-foreground mb-4"
        style={{ background: "var(--gradient-primary)" }}
      >
        {icon}
      </div>
      <h3 className="font-semibold">{title}</h3>
      <p className="text-sm text-muted-foreground mt-1 mb-4">{desc}</p>
      <Button onClick={onClick} disabled={disabled} className="w-full">
        {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
        {actionLabel}
      </Button>
    </div>
  );
}

function StatusDot({ ok }: { ok: boolean }) {
  return ok ? <CheckCircle2 className="h-4 w-4 text-success inline" /> : <Circle className="h-4 w-4 text-muted-foreground/40 inline" />;
}

/* ---------- Tracking Tab ---------- */
function TrackingTab({ batchId }: { batchId: string }) {
  const batch = useStore((s) => s.batches.find((b) => b.id === batchId))!;
  const posted = batch.candidates.filter((c) => c.linkedinPosted).length;
  const pct = batch.candidates.length ? Math.round((posted / batch.candidates.length) * 100) : 0;

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-border bg-card p-6">
        <div className="flex items-end justify-between">
          <div>
            <h3 className="font-semibold flex items-center gap-2"><Linkedin className="h-4 w-4 text-primary" /> LinkedIn engagement</h3>
            <p className="text-sm text-muted-foreground mt-1">Paste each candidate's LinkedIn post link to mark as Posted.</p>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold tabular-nums">{pct}%</div>
            <div className="text-xs text-muted-foreground">{posted} of {batch.candidates.length}</div>
          </div>
        </div>
        <div className="mt-4 h-2 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full transition-all"
            style={{ width: `${pct}%`, background: "var(--gradient-primary)" }}
          />
        </div>
      </div>

      {batch.candidates.length === 0 ? (
        <EmptyHint icon={<Linkedin />} title="No candidates" body="Upload candidates to start tracking." />
      ) : (
        <div className="rounded-2xl border border-border bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="text-left px-4 py-3">Candidate</th>
                <th className="text-left px-4 py-3">Post URL</th>
                <th className="px-4 py-3 w-32">Status</th>
              </tr>
            </thead>
            <tbody>
              {batch.candidates.map((c) => (
                <tr key={c.id} className="border-t border-border">
                  <td className="px-4 py-3 font-medium">{c.name}</td>
                  <td className="px-4 py-3">
                    <Input
                      placeholder="https://linkedin.com/posts/..."
                      defaultValue={c.linkedinPostUrl || ""}
                      onBlur={(e) => {
                        const v = e.target.value.trim();
                        if (v !== (c.linkedinPostUrl || "")) {
                          actions.setLinkedinPost(batchId, c.id, v);
                        }
                      }}
                      className="h-8 text-xs"
                    />
                  </td>
                  <td className="px-4 py-3 text-center">
                    {c.linkedinPosted ? (
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-success-foreground bg-success px-2 py-1 rounded-full">
                        <CheckCircle2 className="h-3 w-3" /> Posted
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground bg-muted px-2 py-1 rounded-full">
                        Pending
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function EmptyHint({ icon, title, body }: { icon: React.ReactNode; title: string; body: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-border bg-card/40 py-14 px-6 text-center">
      <div className="mx-auto h-12 w-12 rounded-xl flex items-center justify-center bg-muted text-muted-foreground mb-3">
        {icon}
      </div>
      <h3 className="font-semibold">{title}</h3>
      <p className="text-sm text-muted-foreground mt-1 max-w-sm mx-auto">{body}</p>
    </div>
  );
}
