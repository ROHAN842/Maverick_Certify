import { Link } from "@tanstack/react-router";
import { Sparkles } from "lucide-react";

export function AppHeader() {
  return (
    <header className="border-b border-border/60 backdrop-blur-md bg-background/70 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2.5 group">
          <div
            className="h-9 w-9 rounded-lg flex items-center justify-center text-primary-foreground shadow-md group-hover:scale-105 transition-transform"
            style={{ background: "var(--gradient-primary)" }}
          >
            <Sparkles className="h-4.5 w-4.5" strokeWidth={2.5} />
          </div>
          <div className="leading-tight">
            <div className="font-display font-bold text-base">Maverick Certify</div>
            <div className="text-[11px] text-muted-foreground -mt-0.5">Automated certificate ops</div>
          </div>
        </Link>
        <nav className="flex items-center gap-1 text-sm font-medium">
          <Link
            to="/"
            activeOptions={{ exact: true }}
            className="px-3 py-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors [&.active]:text-foreground [&.active]:bg-muted"
          >
            Dashboard
          </Link>
        </nav>
      </div>
    </header>
  );
}
